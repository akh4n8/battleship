import os

with open("/home/khan8/Work/battleship/web_showcase/main.py", "w") as f:
    f.write("""import pygame
import sys
import asyncio
import random
from core.game_engine import BattleshipGame, CELL_UNKNOWN, CELL_MISS, CELL_HIT, CELL_SUNK
from bots.sherlock import SherlockBot
from bots.mycroft import MycroftBot

# ==========================================
# PYGAME SHARED SETUP & CONSTANTS
# ==========================================
pygame.init()
CELL_SIZE = 42
MARGIN = 60 
GRID_SIZE = 10

# Triangle Layout: Board Top Center, Sherlock Bottom Left, Mycroft Bottom Right
WINDOW_WIDTH = (MARGIN * 3) + (CELL_SIZE * GRID_SIZE * 2)
WINDOW_HEIGHT = (MARGIN * 3) + (CELL_SIZE * GRID_SIZE * 2)

screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
font = pygame.font.SysFont(None, 28)
small_font = pygame.font.SysFont(None, 18)
label_font = pygame.font.SysFont(None, 22)

BG_COLOR = (25, 25, 30)
GRID_COLOR = (100, 100, 100)
WATER_COLOR = (10, 60, 120)
SHIP_COLOR = (60, 70, 60) 
GHOST_VALID = (0, 255, 0, 120)
GHOST_INVALID = (255, 0, 0, 120)
LABEL_COLOR = (180, 180, 180)
TELEMETRY_COLOR = (255, 200, 100) 

PEG_MISS_COLOR = (220, 220, 220)
PEG_HIT_COLOR = (255, 50, 50)
PEG_SUNK_COLOR = (50, 150, 255)

DIAG_CLAIMED = (150, 150, 150)   
DIAG_ACTIVE = (0, 229, 255)      

HEAT_COLORS = [
    (10, 60, 120),  (50, 120, 160), (80, 160, 120), 
    (180, 180, 60), (220, 120, 40), (255, 50, 50)   
]

# ==========================================
# SHARED RENDERING FUNCTIONS
# ==========================================
def draw_grid_labels(offset_x, offset_y):
    for i in range(GRID_SIZE):
        col_text = label_font.render(str(i + 1), True, LABEL_COLOR)
        col_x = offset_x + (i * CELL_SIZE) + (CELL_SIZE // 2) - (col_text.get_width() // 2)
        screen.blit(col_text, (col_x, offset_y - 25))
        
        row_text = label_font.render(chr(65 + i), True, LABEL_COLOR)
        row_y = offset_y + (i * CELL_SIZE) + (CELL_SIZE // 2) - (row_text.get_height() // 2)
        screen.blit(row_text, (offset_x - 20 - (row_text.get_width() // 2), row_y))

def draw_pegs_and_diagnostics(board, diagnostics, offset_x, offset_y):
    for row in range(GRID_SIZE):
        for col in range(GRID_SIZE):
            rect = pygame.Rect(offset_x + col * CELL_SIZE, offset_y + row * CELL_SIZE, CELL_SIZE, CELL_SIZE)
            inner_rect = rect.inflate(-6, -6)

            track_val = board[row][col]
            if track_val == CELL_MISS:
                pygame.draw.circle(screen, PEG_MISS_COLOR, rect.center, CELL_SIZE // 6)
            elif track_val == CELL_HIT:
                pad = 8
                pygame.draw.line(screen, PEG_HIT_COLOR, (rect.left + pad, rect.top + pad), (rect.right - pad, rect.bottom - pad), 3)
                pygame.draw.line(screen, PEG_HIT_COLOR, (rect.right - pad, rect.top + pad), (rect.left + pad, rect.bottom - pad), 3)
            elif track_val == CELL_SUNK:
                pad = 6
                pygame.draw.line(screen, PEG_SUNK_COLOR, (rect.left + pad, rect.top + pad), (rect.right - pad, rect.bottom - pad), 4)
                pygame.draw.line(screen, PEG_SUNK_COLOR, (rect.right - pad, rect.top + pad), (rect.left + pad, rect.bottom - pad), 4)
            
            if diagnostics and (row, col) in diagnostics.get("active", []):
                pygame.draw.rect(screen, DIAG_ACTIVE, inner_rect, 3, border_radius=4)
                pygame.draw.circle(screen, DIAG_ACTIVE, rect.center, CELL_SIZE * 0.25, 2)

    if diagnostics and "dead_ships" in diagnostics:
        for ship_pegs in diagnostics["dead_ships"]:
            if not ship_pegs: continue
            min_row = min(p[0] for p in ship_pegs)
            max_row = max(p[0] for p in ship_pegs)
            min_col = min(p[1] for p in ship_pegs)
            max_col = max(p[1] for p in ship_pegs)
            ship_rect = pygame.Rect(offset_x + min_col * CELL_SIZE, offset_y + min_row * CELL_SIZE, 
                                    (max_col - min_col + 1) * CELL_SIZE, (max_row - min_row + 1) * CELL_SIZE).inflate(-2, -2)
            pygame.draw.rect(screen, DIAG_CLAIMED, ship_rect, width=3, border_radius=6)

def draw_heatmap_grid(board, heat_map, title_str, offset_x, offset_y):
    draw_grid_labels(offset_x, offset_y)
    title = font.render(title_str, True, (200, 200, 200))
    screen.blit(title, (offset_x, offset_y - 45))

    max_heat = max((max(row) for row in heat_map)) if heat_map else 0

    for row in range(GRID_SIZE):
        for col in range(GRID_SIZE):
            rect = pygame.Rect(offset_x + col * CELL_SIZE, offset_y + row * CELL_SIZE, CELL_SIZE, CELL_SIZE)
            cell_heat = heat_map[row][col]
            if max_heat == 0 or cell_heat == 0:
                color_index = 0
            else:
                ratio = cell_heat / max_heat
                color_index = max(1, int(ratio * (len(HEAT_COLORS) - 1))) 

            pygame.draw.rect(screen, HEAT_COLORS[color_index], rect)
            if cell_heat > 0:
                heat_text = small_font.render(str(cell_heat), True, (255, 255, 255))
                screen.blit(heat_text, heat_text.get_rect(center=rect.center))
            pygame.draw.rect(screen, GRID_COLOR, rect, 1)

# ==========================================
# ASYNC MAIN LOOP FOR WEB
# ==========================================
async def main():
    pygame.display.set_caption("Battleship Thesis - 3-Grid Visualization")
    
    sherlock_bot = SherlockBot()
    mycroft_bot = MycroftBot(safe_mode=False)
    
    def reset_state():
        g = BattleshipGame()
        return g, "SETUP", g.fleet_sizes.copy(), 1, True, -1, False

    game, phase, ships_to_place, current_ship_id, is_horizontal, last_shot_count, show_ships = reset_state()
    presentation_game_id = 1
    
    offset_board_x = (WINDOW_WIDTH - (CELL_SIZE * GRID_SIZE)) // 2
    offset_board_y = MARGIN
    
    offset_sherlock_x = MARGIN
    offset_sherlock_y = (MARGIN * 2) + (CELL_SIZE * GRID_SIZE)
    
    offset_mycroft_x = WINDOW_WIDTH - MARGIN - (CELL_SIZE * GRID_SIZE)
    offset_mycroft_y = (MARGIN * 2) + (CELL_SIZE * GRID_SIZE)
    
    sherlock_heatmap = [[0 for _ in range(10)] for _ in range(10)]
    mycroft_heatmap = [[0 for _ in range(10)] for _ in range(10)]
    sherlock_target = None
    mycroft_target = None
    diagnostics = {}
    dead_sizes = []
    
    bots_need_update = True
    
    running = True
    while running:
        mouse_pos = pygame.mouse.get_pos()
        hover_col = (mouse_pos[0] - offset_board_x) // CELL_SIZE
        hover_row = (mouse_pos[1] - offset_board_y) // CELL_SIZE
        on_board_grid = (0 <= hover_col < GRID_SIZE) and (0 <= hover_row < GRID_SIZE)

        if phase == "PLAY" and not game.is_game_over():
            if game.shot_number != last_shot_count:
                bots_need_update = True
                last_shot_count = game.shot_number
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_h and phase == "PLAY": 
                    show_ships = not show_ships
                elif event.key == pygame.K_r:
                    random.seed(presentation_game_id)
                    game, phase, ships_to_place, current_ship_id, is_horizontal, last_shot_count, show_ships = reset_state()
                    game.place_ships_randomly()
                    ships_to_place = []
                    phase = "PLAY"
                    presentation_game_id += 1
                elif event.key == pygame.K_1:
                    game, phase, ships_to_place, current_ship_id, is_horizontal, last_shot_count, show_ships = reset_state()
                    game.place_ship_manual(0, 0, 5, False, 1) 
                    game.place_ship_manual(2, 0, 4, False, 2) 
                    game.place_ship_manual(4, 2, 3, False, 3) 
                    game.place_ship_manual(4, 5, 3, False, 4) 
                    game.place_ship_manual(8, 0, 2, False, 5) 
                    ships_to_place = []; phase = "PLAY"; presentation_game_id += 1
                elif event.key == pygame.K_2:
                    game, phase, ships_to_place, current_ship_id, is_horizontal, last_shot_count, show_ships = reset_state()
                    game.place_ship_manual(2, 4, 5, True, 1)  
                    game.place_ship_manual(4, 5, 4, False, 2) 
                    game.place_ship_manual(0, 0, 3, False, 3)
                    game.place_ship_manual(8, 0, 3, False, 4)
                    game.place_ship_manual(8, 5, 2, False, 5)
                    ships_to_place = []; phase = "PLAY"; presentation_game_id += 1
                elif event.key == pygame.K_3:
                    game, phase, ships_to_place, current_ship_id, is_horizontal, last_shot_count, show_ships = reset_state()
                    game.place_ship_manual(3, 2, 5, False, 1) 
                    game.place_ship_manual(4, 2, 4, False, 2) 
                    game.place_ship_manual(5, 2, 3, False, 3) 
                    game.place_ship_manual(6, 2, 3, False, 4) 
                    game.place_ship_manual(7, 2, 2, False, 5) 
                    ships_to_place = []; phase = "PLAY"; presentation_game_id += 1
                elif phase == "PLAY" and not game.is_game_over() and not bots_need_update:
                    if event.key == pygame.K_u: 
                        game.undo_last_shot()
                        last_shot_count = -1
                    elif event.key == pygame.K_s and sherlock_target:
                        game.fire_shot(sherlock_target[0], sherlock_target[1])
                    elif event.key == pygame.K_m and mycroft_target:
                        game.fire_shot(mycroft_target[0], mycroft_target[1])
                elif phase == "PLAY" and game.is_game_over():
                    if event.key == pygame.K_n:
                        game, phase, ships_to_place, current_ship_id, is_horizontal, last_shot_count, show_ships = reset_state()
                        sherlock_heatmap = [[0 for _ in range(10)] for _ in range(10)]
                        mycroft_heatmap = [[0 for _ in range(10)] for _ in range(10)]
                        diagnostics = {}
                        presentation_game_id += 1
                        
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if phase == "SETUP":
                    if event.button == 3: is_horizontal = not is_horizontal
                    elif event.button == 1 and on_board_grid and ships_to_place:
                        if game.place_ship_manual(hover_row, hover_col, ships_to_place[0], not is_horizontal, current_ship_id):
                            ships_to_place.pop(0)
                            current_ship_id += 1
                            if not ships_to_place: phase = "PLAY"
                elif phase == "PLAY" and event.button == 1 and on_board_grid and not game.is_game_over() and not bots_need_update:
                    game.fire_shot(hover_row, hover_col)

        screen.fill(BG_COLOR)
        
        draw_heatmap_grid(game.tracking_board, sherlock_heatmap, "Sherlock (Rule-Based)", offset_sherlock_x, offset_sherlock_y)
        
        draw_grid_labels(offset_board_x, offset_board_y)
        title = font.render("Interactive Board", True, (200, 200, 200))
        screen.blit(title, (offset_board_x, offset_board_y - 45))

        if bots_need_update and phase == "PLAY" and not game.is_game_over():
            loading_text = font.render("MCMC Computing...", True, (255, 200, 50))
            screen.blit(loading_text, (offset_board_x + (CELL_SIZE * 10) - loading_text.get_width(), offset_board_y - 45))

        for row in range(GRID_SIZE):
            for col in range(GRID_SIZE):
                pygame.draw.rect(screen, WATER_COLOR, pygame.Rect(offset_board_x + col * CELL_SIZE, offset_board_y + row * CELL_SIZE, CELL_SIZE, CELL_SIZE))
                pygame.draw.rect(screen, GRID_COLOR, pygame.Rect(offset_board_x + col * CELL_SIZE, offset_board_y + row * CELL_SIZE, CELL_SIZE, CELL_SIZE), 1)

        if phase == "SETUP" or show_ships:
            for ship_id, pegs in game.ship_pegs.items():
                if pegs:
                    min_row, max_row = min(p[0] for p in pegs), max(p[0] for p in pegs)
                    min_col, max_col = min(p[1] for p in pegs), max(p[1] for p in pegs)
                    ship_rect = pygame.Rect(offset_board_x + min_col * CELL_SIZE, offset_board_y + min_row * CELL_SIZE, (max_col - min_col + 1) * CELL_SIZE, (max_row - min_row + 1) * CELL_SIZE).inflate(-6, -6)
                    pygame.draw.rect(screen, SHIP_COLOR, ship_rect, border_radius=10)

        draw_pegs_and_diagnostics(game.tracking_board, diagnostics if show_ships else {}, offset_board_x, offset_board_y)

        if phase == "SETUP":
            if on_board_grid and ships_to_place:
                ship_width = (ships_to_place[0] * CELL_SIZE) if is_horizontal else CELL_SIZE
                ship_height = CELL_SIZE if is_horizontal else (ships_to_place[0] * CELL_SIZE)
                ghost_rect = pygame.Rect(offset_board_x + hover_col * CELL_SIZE, offset_board_y + hover_row * CELL_SIZE, ship_width, ship_height).inflate(-6, -6)
                color = GHOST_VALID if game.can_place(hover_row, hover_col, ships_to_place[0], not is_horizontal) else GHOST_INVALID
                pygame.draw.rect(screen, color, ghost_rect, border_radius=10)
            screen.blit(small_font.render("Left Click: Place | Right Click: Rotate | [R] Randomize | [1/2/3] Presets", True, LABEL_COLOR), (MARGIN, WINDOW_HEIGHT - 30))
        
        elif phase == "PLAY":
            if not game.is_game_over():
                controls_str = "[Click] Fire Shot | [S] Sherlock Shoot | [M] Mycroft Shoot | [U] Undo | [H] Toggle Debug UI | [R] Randomize | [1/2/3] Presets"
                screen.blit(small_font.render(controls_str, True, TELEMETRY_COLOR), (MARGIN, WINDOW_HEIGHT - 30))
            else:
                screen.blit(font.render(f"Game Over! Cleared in {game.shot_number} shots. Press [N] to restart or [R] to randomize.", True, (0, 255, 0)), (MARGIN, WINDOW_HEIGHT - 40))

        draw_heatmap_grid(game.tracking_board, mycroft_heatmap, "Mycroft (MCMC)", offset_mycroft_x, offset_mycroft_y)

        pygame.display.update()
        pygame.time.Clock().tick(60)
        await asyncio.sleep(0)

        # AFTER DRAWING THE NEW PEG AND "COMPUTING" TEXT: DO THE HEAVY LIFTING!
        if bots_need_update and phase == "PLAY" and not game.is_game_over():
            random.seed((presentation_game_id * 10000) + game.shot_number)
            s_target, _, s_dead, s_diag = sherlock_bot.get_best_move(game.tracking_board, game.move_history)
            sherlock_target = s_target
            sherlock_heatmap = sherlock_bot.get_heatmap(game.tracking_board, s_dead)
            
            if s_diag.get("active") and s_target:
                sherlock_heatmap[s_target[0]][s_target[1]] = 100
            
            random.seed((presentation_game_id * 10000) + game.shot_number + 5000)
            m_target, _, m_dead, m_diag = mycroft_bot.get_best_move(game.tracking_board, game.move_history)
            mycroft_target = m_target
            mycroft_heatmap = mycroft_bot.get_heatmap(game.tracking_board, m_dead)
            
            diagnostics = s_diag
            dead_sizes = s_dead
            bots_need_update = False

if __name__ == "__main__":
    asyncio.run(main())
""")
