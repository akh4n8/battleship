import random
from core.game_engine import CELL_UNKNOWN, CELL_MISS, CELL_HIT, CELL_SUNK

class SherlockBot:
    def __init__(self):
        self.original_fleet = [5, 4, 3, 3, 2]
        self.parity_offset = random.choice([0, 1])

    def get_best_move(self, board, move_history):
        active_hits, dead_ships, claimed_hits, dead_sizes = self._analyze_board_state(board, move_history)

        diagnostics = {
            "active": active_hits,
            "suspended": [], 
            "claimed": claimed_hits,
            "dead_ships": dead_ships,
            "deficit": False 
        }

        if active_hits:
            target = self._execute_linear_kill(board, active_hits, claimed_hits)
            if target:
                return target, "Linear Kill", dead_sizes, diagnostics

        target = self._execute_gravitational_hunt(board, dead_sizes, dead_ships)
        return target, "Gravitational Hunt", dead_sizes, diagnostics

    # ==========================================
    # CHRONOLOGICAL CONSTRAINT SOLVER
    # ==========================================

    def _analyze_board_state(self, board, move_history):
        size = len(board)
        all_hits = set()
        sunks = []
        peg_times = {(m["x"], m["y"]): m["shotNumber"] for m in move_history if m["result"] != "MISS"}

        for r in range(size):
            for c in range(size):
                if board[r][c] == CELL_HIT: all_hits.add((r, c))
                if board[r][c] == CELL_SUNK: sunks.append((r, c))

        sunks.sort(key=lambda s: peg_times.get(s, float('inf')))

        result = self._solve_board(board, sunks, peg_times, self.original_fleet.copy(), [], [], all_hits)
        
        if result:
            dead_ships, dead_sizes, _ = result
            claimed_hits = set(peg for ship in dead_ships for peg in ship)
        else:
            dead_ships = [[s] for s in sunks]
            claimed_hits = set(sunks)
            dead_sizes = [1] * len(sunks)

        active_hits = list(all_hits - claimed_hits)
        return active_hits, dead_ships, list(claimed_hits), dead_sizes

    def _solve_board(self, board, sunks, peg_times, available_fleet, current_dead_ships, current_dead_sizes, all_hits):
        if not sunks:
            claimed_set = set(peg for ship in current_dead_ships for peg in ship)
            leftovers = all_hits - claimed_set
            
            if available_fleet and leftovers:
                min_ship_size = min(available_fleet)
                size = len(board)
                
                for hit in leftovers:
                    r, c = hit
                    
                    left = c
                    while left > 0 and board[r][left-1] in [CELL_UNKNOWN, CELL_HIT] and (r, left-1) not in claimed_set:
                        left -= 1
                    right = c
                    while right < size - 1 and board[r][right+1] in [CELL_UNKNOWN, CELL_HIT] and (r, right+1) not in claimed_set:
                        right += 1
                    horiz_len = right - left + 1
                    
                    # THE FIX: Must contain open water to be a living ship
                    horiz_unknowns = sum(1 for i in range(left, right + 1) if board[r][i] == CELL_UNKNOWN)
                    
                    up = r
                    while up > 0 and board[up-1][c] in [CELL_UNKNOWN, CELL_HIT] and (up-1, c) not in claimed_set:
                        up -= 1
                    down = r
                    while down < size - 1 and board[down+1][c] in [CELL_UNKNOWN, CELL_HIT] and (down+1, c) not in claimed_set:
                        down += 1
                    vert_len = down - up + 1
                    
                    # THE FIX: Must contain open water to be a living ship
                    vert_unknowns = sum(1 for i in range(up, down + 1) if board[i][c] == CELL_UNKNOWN)
                    
                    valid_horiz = horiz_len >= min_ship_size and horiz_unknowns > 0
                    valid_vert = vert_len >= min_ship_size and vert_unknowns > 0
                    
                    if not (valid_horiz or valid_vert):
                        return None 

            return current_dead_ships, current_dead_sizes, len(leftovers)

        sunk = sunks[0]
        sunk_time = peg_times.get(sunk, float('inf'))

        unique_sizes = list(set(available_fleet))
        unique_sizes.sort(reverse=True)
        
        current_claimed_set = set(peg for ship in current_dead_ships for peg in ship)

        best_result = None
        best_score = float('inf')

        for size in unique_sizes:
            placements = self._get_valid_placements(board, sunk, sunk_time, size, peg_times)
            
            for placement in placements:
                placement_set = set(placement)
                
                if not placement_set.intersection(current_claimed_set):
                    new_dead_ships = current_dead_ships + [placement]
                    new_fleet = available_fleet.copy()
                    new_fleet.remove(size)
                    new_dead_sizes = current_dead_sizes + [size]

                    result = self._solve_board(board, sunks[1:], peg_times, new_fleet, new_dead_ships, new_dead_sizes, all_hits)
                    
                    if result:
                        _, _, score = result
                        if score < best_score:
                            best_score = score
                            best_result = result
                            
        return best_result 

    def _get_valid_placements(self, board, sunk, sunk_time, size, peg_times):
        placements = []
        board_size = len(board)
        sr, sc = sunk
        
        for c_start in range(sc - size + 1, sc + 1):
            valid = True
            peg_list = []
            for i in range(size):
                r, c = sr, c_start + i
                if 0 <= r < board_size and 0 <= c < board_size:
                    if (r, c) == sunk:
                        peg_list.append((r, c))
                    elif (r, c) in peg_times and peg_times[(r, c)] < sunk_time:
                        peg_list.append((r, c))
                    else:
                        valid = False; break
                else:
                    valid = False; break
            if valid: placements.append(peg_list)
                
        for r_start in range(sr - size + 1, sr + 1):
            valid = True
            peg_list = []
            for i in range(size):
                r, c = r_start + i, sc
                if 0 <= r < board_size and 0 <= c < board_size:
                    if (r, c) == sunk:
                        peg_list.append((r, c))
                    elif (r, c) in peg_times and peg_times[(r, c)] < sunk_time:
                        peg_list.append((r, c))
                    else:
                        valid = False; break
                else:
                    valid = False; break
            if valid: placements.append(peg_list)
                
        return placements

    # ==========================================
    # LINEAR KILL TRACER
    # ==========================================

    def _execute_linear_kill(self, board, active_hits, claimed_hits):
        pruned_hits = [h for h in active_hits if h not in claimed_hits]
        unvisited = set(pruned_hits)
        size = len(board)

        while unvisited:
            start = next(iter(unvisited))
            cluster = set()
            queue = [start]

            while queue:
                current = queue.pop(0)
                if current not in cluster:
                    cluster.add(current)
                    unvisited.discard(current)
                    r, c = current
                    neighbors = [(r, c-1), (r, c+1), (r-1, c), (r+1, c)]
                    for n in neighbors:
                        if n in pruned_hits and n not in cluster:
                            queue.append(n)

            rows = set(r for r, c in cluster)
            cols = set(c for r, c in cluster)

            if len(cluster) == 1:
                valid_targets = self._get_unknown_neighbors(board, cluster.pop())
                if valid_targets: return random.choice(valid_targets)
                
            elif len(rows) == 1: 
                r = list(rows)[0]
                endpoints = []
                
                c = min(cols)
                # THE TRUE FIX: Only traverse the verified active cluster!
                while (r, c) in cluster: c -= 1
                if c >= 0 and board[r][c] == CELL_UNKNOWN: endpoints.append((r, c))
                
                c = max(cols)
                # THE TRUE FIX: Only traverse the verified active cluster!
                while (r, c) in cluster: c += 1
                if c < size and board[r][c] == CELL_UNKNOWN: endpoints.append((r, c))
                
                if endpoints: return random.choice(endpoints)
                
            elif len(cols) == 1: 
                c = list(cols)[0]
                endpoints = []
                
                r = min(rows)
                # THE TRUE FIX: Only traverse the verified active cluster!
                while (r, c) in cluster: r -= 1
                if r >= 0 and board[r][c] == CELL_UNKNOWN: endpoints.append((r, c))
                
                r = max(rows)
                # THE TRUE FIX: Only traverse the verified active cluster!
                while (r, c) in cluster: r += 1
                if r < size and board[r][c] == CELL_UNKNOWN: endpoints.append((r, c))
                
                if endpoints: return random.choice(endpoints)
                
            else:
                valid_endpoints = []
                for r, c in cluster:
                    for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                        if (r + dr, c + dc) in cluster:
                            curr_r, curr_c = r, c
                            # This internal loop only traverses the active cluster, 
                            # so it is naturally safe from jumping corpses.
                            while (curr_r, curr_c) in cluster:
                                curr_r += dr
                                curr_c += dc
                            
                            if 0 <= curr_r < size and 0 <= curr_c < size:
                                if board[curr_r][curr_c] == CELL_UNKNOWN:
                                    valid_endpoints.append((curr_r, curr_c))
                
                if valid_endpoints:
                    return random.choice(valid_endpoints)

            for hit in cluster:
                valid_targets = self._get_unknown_neighbors(board, hit)
                if valid_targets: return valid_targets[0]
                
        return None

    def _get_unknown_neighbors(self, board, peg):
        r, c = peg
        neighbors = [(r, c-1), (r, c+1), (r-1, c), (r+1, c)]
        size = len(board)
        return [(nr, nc) for nr, nc in neighbors if 0 <= nr < size and 0 <= nc < size and board[nr][nc] == CELL_UNKNOWN]

    # ==========================================
    # GRAVITATIONAL HUNT MAP & SWEEPER
    # ==========================================

    def _get_perpendicular_ends(self, ship_pegs, board):
        """Calculates the 4 corner 'armpit' squares perpendicular to the extreme ends of a ship."""
        targets = []
        if len(ship_pegs) < 2: 
            return targets
            
        sorted_pegs = sorted(list(ship_pegs))
        size = len(board)
        
        r1, c1 = sorted_pegs[0]  # First end
        r2, c2 = sorted_pegs[-1] # Opposite end
        
        if r1 == r2: # Horizontal ship
            potentials = [(r1-1, c1), (r1+1, c1), (r2-1, c2), (r2+1, c2)]
        else: # Vertical ship
            potentials = [(r1, c1-1), (r1, c1+1), (r2, c2-1), (r2, c2+1)]
            
        for r, c in potentials:
            if 0 <= r < size and 0 <= c < size and board[r][c] == CELL_UNKNOWN:
                targets.append((r, c))
                
        return targets

    def _execute_gravitational_hunt(self, board, dead_sizes, dead_ships):
        size = len(board)
        
        # --- PHASE 1: Primary Parity Hunt ---
        heat_map = self.get_heatmap(board, dead_sizes, use_parity=True)
        max_heat = -1
        best_moves = []
        
        for r in range(size):
            for c in range(size):
                if board[r][c] == CELL_UNKNOWN:
                    heat = heat_map[r][c]
                    if heat > max_heat:
                        max_heat = heat
                        best_moves = [(r, c)]
                    elif heat == max_heat:
                        best_moves.append((r, c))
                        
        if max_heat > 0 and best_moves: 
            return random.choice(best_moves)

        # --- PHASE 2: 4-Tier Blindspot Sweeper (The Corner Hunter) ---
        
        # Priority 2.1: Perpendicular corners (ends) of the 3-ships
        three_ship_ends = []
        for ship in dead_ships:
            if len(ship) == 3:
                three_ship_ends.extend(self._get_perpendicular_ends(ship, board))
        if three_ship_ends: 
            return random.choice(three_ship_ends)
            
        # Priority 2.2: Perpendicular corners (ends) of all other corpses
        other_ship_ends = []
        for ship in dead_ships:
            if len(ship) != 3:
                other_ship_ends.extend(self._get_perpendicular_ends(ship, board))
        if other_ship_ends: 
            return random.choice(other_ship_ends)

        # Priority 2.3: General perimeter (flat edges) of the 3-ships
        three_perimeter = []
        for ship in dead_ships:
            if len(ship) == 3:
                for r, c in ship:
                    for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                        nr, nc = r + dr, c + dc
                        if 0 <= nr < size and 0 <= nc < size and board[nr][nc] == CELL_UNKNOWN:
                            three_perimeter.append((nr, nc))
        if three_perimeter: 
            return random.choice(three_perimeter)

        # Priority 2.4: General perimeter (flat edges) of all other corpses
        other_perimeter = []
        for ship in dead_ships:
            if len(ship) != 3:
                for r, c in ship:
                    for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                        nr, nc = r + dr, c + dc
                        if 0 <= nr < size and 0 <= nc < size and board[nr][nc] == CELL_UNKNOWN:
                            other_perimeter.append((nr, nc))
        if other_perimeter: 
            return random.choice(other_perimeter)

        # --- PHASE 3: Emergency Non-Parity Hunt ---
        heat_map_em = self.get_heatmap(board, [5, 4, 3, 3], use_parity=False) 
        max_heat_em = -1
        best_moves_em = []
        
        for r in range(size):
            for c in range(size):
                if board[r][c] == CELL_UNKNOWN:
                    heat = heat_map_em[r][c]
                    if heat > max_heat_em:
                        max_heat_em = heat
                        best_moves_em = [(r, c)]
                    elif heat == max_heat_em:
                        best_moves_em.append((r, c))
                        
        if max_heat_em > 0 and best_moves_em: 
            return random.choice(best_moves_em)
        
        # --- PHASE 4: Absolute Fallback ---
        open_water = [(r, c) for r in range(size) for c in range(size) if board[r][c] == CELL_UNKNOWN]
        if open_water:
            return random.choice(open_water)
            
        return (0, 0)

    def get_heatmap(self, board, dead_sizes, use_parity=True):
        size = len(board)
        heat_map = [[0 for _ in range(size)] for _ in range(size)]
        
        living_fleet = self.original_fleet.copy()
        for ds in dead_sizes:
            size_to_remove = 5 if ds > 5 else ds
            if size_to_remove in living_fleet:
                living_fleet.remove(size_to_remove)
                
        if not living_fleet: living_fleet.append(2)
        unique_ships = list(set(living_fleet))

        for ship_size in unique_ships:
            for r in range(size):
                for c in range(size - ship_size + 1):
                    self._evaluate_hunt_placement(board, heat_map, r, c, ship_size, True, use_parity)
            for r in range(size - ship_size + 1):
                for c in range(size):
                    self._evaluate_hunt_placement(board, heat_map, r, c, ship_size, False, use_parity)

        return heat_map

    def _evaluate_hunt_placement(self, board, heat_map, start_r, start_c, ship_size, is_horizontal, use_parity):
        for i in range(ship_size):
            r = start_r if is_horizontal else start_r + i
            c = start_c + i if is_horizontal else start_c
            if board[r][c] in [CELL_MISS, CELL_SUNK, CELL_HIT]: return

        for i in range(ship_size):
            r = start_r if is_horizontal else start_r + i
            c = start_c + i if is_horizontal else start_c
            if board[r][c] == CELL_UNKNOWN:
                if use_parity:
                    heat_map[r][c] += 0 if (r + c) % 2 == self.parity_offset else 1
                else:
                    heat_map[r][c] += 1