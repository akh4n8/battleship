import random
import re
from bots.mycroft import MycroftBot
from core.game_engine import CELL_UNKNOWN

class EntropyBot:
    def __init__(self):
        # We enable safe_mode so Mycroft applies parity masking.
        self.mycroft = MycroftBot(safe_mode=True)

    def get_best_move(self, board, move_history):
        # Let Mycroft run the MCMC physics engine to generate the raw valid boards
        fallback_target, log, ui_sizes, diagnostics = self.mycroft.get_best_move(board, move_history)
        
        # Extract valid_universes to calculate P(Hit)
        match = re.search(r'\((\d+) Steps\)', log)
        if not match:
            # Fallback if MCMC exhausted or failed
            return fallback_target, "Entropy Fallback (MCMC Failed)", ui_sizes, diagnostics
            
        valid_universes = int(match.group(1))
        if valid_universes == 0:
            return fallback_target, "Entropy Fallback (0 Universes)", ui_sizes, diagnostics
            
        heatmap = self.mycroft.last_heatmap
        max_heat = max([max(row) for row in heatmap])
        
        # EXPLOIT PHASE: Assassin Mode / Guaranteed Hits
        # If any square has > 85% chance of being a hit, the mathematical value of taking the hit
        # outweighs the information gain of exploring. We must sink ships to win.
        if max_heat >= 0.85 * valid_universes:
            return fallback_target, f"Entropy Exploit (P >= 0.85)", ui_sizes, diagnostics
            
        # EXPLORE PHASE: Pure Entropy Minimization
        # We want to shoot the square that divides the remaining valid universes perfectly in half.
        # This guarantees maximum information gain (elimination of 50% of the state space) whether hit or miss.
        target_half_heat = valid_universes / 2.0
        
        best_diff = float('inf')
        best_moves = []
        
        for r in range(10):
            for c in range(10):
                if board[r][c] == CELL_UNKNOWN:
                    heat = heatmap[r][c]
                    diff = abs(heat - target_half_heat)
                    if diff < best_diff:
                        best_diff = diff
                        best_moves = [(r, c)]
                    elif diff == best_diff:
                        best_moves.append((r, c))
                        
        if best_moves:
            target = random.choice(best_moves)
            p_hit = (heatmap[target[0]][target[1]] / valid_universes) * 100
            return target, f"Entropy Hunt (P={p_hit:.1f}%)", ui_sizes, diagnostics
            
        return fallback_target, log, ui_sizes, diagnostics

    def get_heatmap(self, board, dead_sizes):
        return self.mycroft.get_heatmap(board, dead_sizes)
